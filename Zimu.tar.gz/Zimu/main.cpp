// Zimu/main.cpp
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
// 导入实现的类
#include <getshotinfo.h>
int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;
    Shotinfo *showmyinfo = new Shotinfo();
    // 设置getshotinfo在qml中的别名为showmyinfo
    engine.rootContext()->setContextProperty("myshotinfo",showmyinfo);
    // 设置与qml实现图片刷新的接口路径，diffurls。接口的类showmyinfo->m_pImgProvider
    engine.addImageProvider(QLatin1String("diffurls"),showmyinfo->m_pImgProvider);
    // 设置主qml的路径
    engine.load(QUrl(QStringLiteral("qrc:/main/Main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;
    return app.exec();
}
