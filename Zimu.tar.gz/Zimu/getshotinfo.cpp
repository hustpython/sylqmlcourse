#include <getshotinfo.h>
#include<QImage>
#include<QRgb>
#include<QColor>
#include <QDebug>
#include <QImage>
Shotinfo::Shotinfo(QObject *parent) :
    QObject(parent)
{
    // 初始化创建一个新 ImageProvider类
    m_pImgProvider = new ImageProvider();
}
Shotinfo::~Shotinfo()
{
    // 删除ImageProvider类
    delete m_pImgProvider;
}
QString Shotinfo::imgurl()
{
    // 只读，返回myimgurl
    return myimgurl;
}
int Shotinfo::sourcewidth()
{
    // 只读，返回mysourcewidth
    return mysourcewidth;
}
void Shotinfo::saveImage(QString saveurl,int scaled)
{
    // 保存图片
    // 设置保存路径
    QString ressaveurl = saveurl.mid(7)+"/字幕拼图.png";
    QImage scaledimg;
    if(scaled < (m_pImgProvider->img.width())/4)
    {
        scaled = (m_pImgProvider->img.width())/4;
    }
    double scaledwidthbili = scaled*1.0 / (m_pImgProvider->img.width()*1.0);
    // 对图片进行缩放
    scaledimg = m_pImgProvider->img.scaled(scaled,m_pImgProvider->img.height()*scaledwidthbili);
    scaledimg.save(ressaveurl);
}
void Shotinfo::setImage(int scaledwidth,double pos1,double pos2,double mainposition)
{
    if(myimgurls.length()>0)
    {
        QImage tempimg;
        // 读入第一张图片
        QString tempurl =myimgurls[0].mid(7);
        tempimg.load (tempurl);
        // 图片的宽度
        mysourcewidth = tempimg.width();
        int totalheight;
        // 图片长宽比
        double scaledbili = (mysourcewidth*1.0) / (scaledwidth*1.0);
        // 还原出原图片的字幕上面一条线位置
        int pos1scaled = pos1*scaledbili;
        // 还原图片字幕的第二条直线位置
        int pos2scaled = pos2*scaledbili;
        // 还原主图区域直线的位置
        int mainpositionscaled = mainposition*scaledbili;
        // 每一个图片字幕的高度
        int zimuheight = pos2scaled - pos1scaled;
        // 图片的数目
        int zimucount = myimgurls.length()-1;
        // 拼接图片的总高度
        totalheight = pos2scaled - mainpositionscaled + zimucount *zimuheight;
        // 依据计算的拼接图片的宽度和高度，新建一个QImage
        QImage lastimg(mysourcewidth,totalheight,QImage::Format_RGB32);
        for(int i=0;i<myimgurls.length();i++)
        {
            QImage img;
            // 初始的y值
            int initialy;
            if(i==mymainindex)
            {
                // 如果图片是主图，initialy为主图位置
                initialy = mainpositionscaled;
            }
            else
            {
                // 否则是第一条字幕线位置
                initialy = pos1scaled;
            }
            // 加载图片
            img.load(myimgurls[i].mid(7));
            for(int x = 0;x<img.width();x++)
            {
                // 对初始y和第二条直线的区域的像素进行操作
                for(int y = initialy;y<pos2scaled;y++)
                {
                    QColor oldColor;
                    int r,g,b;
                    oldColor = QColor(img.pixel(x,y));
                    r = oldColor.red();
                    g = oldColor.green();
                    b = oldColor.blue();
                    if(i<=mymainindex)
                    {
                    // 对于主图索引前面的图片，则每张图片的剪切区域固定为字幕宽度
                    lastimg.setPixel(x,i*zimuheight+y-initialy,qRgb(r,g,b));
                    }
                    else
                    {
                     // 对于主图索引后面的图片有i-1个图片是字幕宽度，还有一个主图区域
                     lastimg.setPixel(x,(i-1)*(zimuheight)+pos2scaled - mainpositionscaled + y-initialy,qRgb(r,g,b));
                    }
            }
            }
        }
        m_pImgProvider->img = lastimg;
        // 完成拼接，触发更新前端
        emit callQmlRefeshImg();
    }
}
void Shotinfo::setImgurl(QString &imgurl)
{
    // 设置imgurl
    if (myimgurl != imgurl)
            {
               myimgurl = imgurl;
               emit setHeight();
            }
}
QVector<QString> Shotinfo::imgurls()
{
    // 返回myimgurls
    return myimgurls;
}
void Shotinfo::setImgurls(QVector<QString> &imgurls)
{
    // 设置imgurls
    if(myimgurls != imgurls)
    {
        myimgurls = imgurls;
    }
}

int Shotinfo::mainindex()
{
    return mymainindex;
}
void Shotinfo::setMainindex(int &mainindex)
{
     // 设置主图index
     mymainindex = mainindex;
}
double Shotinfo::imgscaleheight()
{
   return myimgscaleheight;
}
void Shotinfo::setHeight()
{
    // 设置图片的长宽比，传递给前端显示。
    QImage tempimg;
    QString y = myimgurl.mid(7);
    tempimg.load(y);
    double w = tempimg.width();
    double h = tempimg.height();
    myimgscaleheight = w/h;
}



