#ifndef GetSHOTINFO_H
#define GetSHOTINFO_H
#endif // GetSHOTINFO_H
#include<QVector>
#include<QObject>
#include<QDebug>
#include<QImage>
#include<imageprovider.h>
// 定义类
class Shotinfo:public QObject
{
    Q_OBJECT
    // 定义imgurl的只读属性imgurl,可写属性setImgurl
    Q_PROPERTY(QString imgurl READ imgurl WRITE setImgurl)
    // 定义imgurls的只读属性imgurls,可写属性setImgurls
    Q_PROPERTY(QVector<QString> imgurls READ imgurls WRITE setImgurls)
    // 定义 mainindex的只读属性mainindex，可写属性setMainindex
    Q_PROPERTY(int mainindex READ mainindex WRITE setMainindex)
    // 定义sourcewidth的只读属性sourcewidth
    Q_PROPERTY(int sourcewidth READ sourcewidth)
    // 定义imgscaleheight的只读属性imgscaleheight
    Q_PROPERTY(double imgscaleheight READ imgscaleheight)
signals:
    // 定义一个信号，用来触发前端刷新视图
    void callQmlRefeshImg();
public:
    // 构造函数
    explicit Shotinfo(QObject *parent = 0);
    // 析构函数
    ~Shotinfo();
    // 用来保存图片的url
    QString imgurl();
    // 用来保存图片宽度
    int sourcewidth();
    // 用来设置图片url
    void setImgurl(QString &imgurl);
    // 用来保存图片路径的向量
    QVector<QString> imgurls();
    // 用来设置图片路径向量
    void setImgurls(QVector<QString> &imgurls);
    // 用来保存主图索引
    int mainindex();
    // 用来设置主图索引
    void setMainindex(int &mainindex);
    // 用来保存图片高度
    double imgscaleheight();
    // 用来设置图片的高度
    Q_INVOKABLE void setHeight();
    // ImageProvider向前端提供图片
    ImageProvider *m_pImgProvider;
public slots:
    void setImage(int scaledwidth,double pos1,double pos2,double mainposition);
    void saveImage(QString saveurl,int scaled);
private:
    QString myimgurl;
    QVector<QString> myimgurls;
    int mymainindex = -1;
    int mysourcewidth = 0;
    double myimgscaleheight;
};
